import DiscoverContainer from "./DiscoverContainer";

export default DiscoverContainer;