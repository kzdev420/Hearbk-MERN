import LandingPageContainer from './LandingPage';

export default LandingPageContainer;