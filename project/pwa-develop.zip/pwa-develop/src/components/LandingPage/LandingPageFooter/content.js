export default {
    ABOUT_US: 'About Us',
    MANAGE_PREFERENCES: 'Manage Preferences',
    TERMS_AND_CONDITIONS: 'Terms & Conditions',
    COOKIE_POLICY: 'Cookie Policy',
    PRIVACY_POLICY: 'Privacy Policy',
    REFUND_POLICY: 'Refund Policy',
    
    
}