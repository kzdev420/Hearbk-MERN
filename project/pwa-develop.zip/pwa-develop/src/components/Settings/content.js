export default {
    HEADER: "SETTINGS",
    POINTS_LABEL: "POINTS",
    POINTS: "250",
    BALANCE_LABEL: "BALANCE",
    BALANCE_SIGN: "$",
    BALANCE_DOLLARS: "75",
    BALANCE_CENTS: ".89",
    STATUS: "NEW LISTENER",
    INSIDER: "Insider", 
    LOGOUT: "Logout"
};