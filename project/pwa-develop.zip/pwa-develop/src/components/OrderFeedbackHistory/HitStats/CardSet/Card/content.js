export default {
    LISTENERS: `LISTENERS`,
    HITS: `HITS`,
    MISSES: `MISSES`,
    POTENTIAL: `POTENTIAL`
};