export default {
    TITLE_1: `WHICH TYPE OF FEEDBACK`,
    TITLE_2: `WOULD YOU LIKE TO RECEIVE?`,
    SUBTITLE_1A: `HIT`,
    SUBTITLE_1B: `CAMPAIGN`,
    SUBDESCRIPTION_1: `Boost your track in front of active listeners on the app and get rated`,
    BUTTON_TEXT_1: `START HIT CAMPAIGN`,
    SUBTITLE_2A: `PRO`,
    SUBTITLE_2B: `FEEDBACK`,
    SUBDESCRIPTION_2: `Request feedback on your tracks from music influencers you choose`,
    BUTTON_TEXT_2: `COMING SOON`
};