export default {
    FAIL: `Upload failed. Please try again !`,
    RETRY_UPLOAD: `Retry Upload`,
};