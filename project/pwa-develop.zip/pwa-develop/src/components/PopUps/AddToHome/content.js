export default {
    MAIN_HEADER: `hearbk.com`,
    DESCRIPTION_PART_1: `Tap `,
    DESCRIPTION_PART_2: ` then select`,
    DESCRIPTION_PART_3: `Add to Home Screen `,
    DESCRIPTION_PART_4: `to install`,
    DESCRIPTION_PART_5: `this app on your device`,
    OK_LABEL: `OK`
}