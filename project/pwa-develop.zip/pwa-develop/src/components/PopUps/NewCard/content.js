export default {
    MAIN_HEADER: "ADD A NEW CARD",
    INPUT_HEADER_1: "NAME ON CARD",
    INPUT_PLACEHOLDER_1: "Name on card",
    INPUT_HEADER_2: "CARD NUMBER",
    INPUT_PLACEHOLDER_2: "---- / ---- / ---- / ----",
    INPUT_HEADER_3: "EXPIRY DATE",
    INPUT_PLACEHOLDER_3: "-- / ----",
    INPUT_HEADER_4: "CVC",
    INPUT_PLACEHOLDER_4: "---",
    SAVE_CARD_LABEL: "SAVE CARD"
}