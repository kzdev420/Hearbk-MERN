export default {
    ACCEPT: `ACCEPT`,
    DESCRIPTION_1A: `We use cookies to improve your`,
    DESCRIPTION_1B: `experience on our site and to show`,
    DESCRIPTION_1C: `you personalized advertising.`,
    DESCRIPTION_2A: `To find out more, read our privacy`,
    DESCRIPTION_2B: `policy and cookie policy`,
    BUTTON_ONE_TEXT: `Manage Preferences`,
    BUTTON_TWO_TEXT: `Privacy Policy`,
    BUTTON_THREE_TEXT: `Cookie Policy`
}