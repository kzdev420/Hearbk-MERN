export const discoverSelector = (state) => ({
    tracks: state.discover.tracks,
});
