export default {
    SALT_ROUNDS: 10,
}