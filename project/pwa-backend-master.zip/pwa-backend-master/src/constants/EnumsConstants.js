export const GENDER_ENUM = ["male", "female", "non-binary"];
export const MEDIA_TYPE_ENUM = ["YOU_TUBE", "FILE_UPLOAD"];
export const FEEDBACK_TYPE = {
  HIT: "HIT",
  MISS: "MISS",
  POTENTIAL: "POTENTIAL",
};
export const USER_FEEDBACK_TYPE = ["HIT", "PRO"];