export default {
    USERS_COLLECTION: 'users',
    ORDERS_COLLECTION: 'orders',
    FEEDBACK_COLLECTION: 'feedbacks',
    GENRES_COLLECTION: 'genres',
    LISTERNER_TAGS_COLLECTION: 'listener_tags',
    DISCOVER_COLLECTION: 'discovers',
    PROMOTION_COLLECTION: 'promotions',
    USER_PROMOTION: 'user_promotion'
};