export default {
    LOGIN_LABEL: "LOG IN",
    LOGIN_TEXT: "to your HEARBK account.",
    EMAIL_ADDRESS: "EMAIL ADDRESS",
    PASSWORD: "PASSWORD",
    REMEMBER: "Remember me",
    FORGOT_PASSWORD: "Forgot Password?"
};