export default {
    PROMO_LABEL: "Enter a promo code"
}