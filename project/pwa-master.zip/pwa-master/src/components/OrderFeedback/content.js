export default {
  ORDER: "ORDER",
  FEEDBACK: "FEEDBACK",
  HIT_CAMPAIGN_HEADER: "START A HIT CAMPAIGN",
  HIT_CAMPAIGN_DESCRIPTION:
    "Add your track(s) and we'll share your music with people looking to discover new music. Each listener will rate your track a HIT, a MISS or POTENTIAL.",
  HIT_CAMPAIGN_DESCRIPTION1: `When the campaign completes, we'll share  a summary of all ratings with you!`,
  HIT: "HIT",
  CAMPAIGN: "CAMPAIGN",
  ADD_ANOTHER_TRACK: "+ ADD ANOTHER TRACK",
  ORDER_NOW_BUTTON: "ORDER NOW",
};
