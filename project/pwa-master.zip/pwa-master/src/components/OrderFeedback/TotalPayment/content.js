export default {
    TOTAL_PAY_TEXT: "TOTAL TO PAY",
    CURRENCY: "$",
}