export default {
    TITLE_1: "DISCOVER",
    TITLE_2: "HITS",
    ICON_CONTAINER_HEADER: "Rate The Track",
    MISS: "MISS",
    POTENTIAL: "POTENTIAL",
    HIT: "HIT"
};