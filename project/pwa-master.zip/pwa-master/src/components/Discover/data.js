const data = [
    {
        iconName: "pinkfloyd",
        display_name: "@pinkfloyd",
        trackUrl: "https://www.youtube.com/embed/tiF-q2h7tSA",
        trackTitle: "Wish You Were Here",
        songLength: "6:08",
        type: "video"
    }
    // {
    //     iconName: "bush",
    //     display_name: "@bush",
    //     trackUrl: "https://www.youtube.com/embed/-ehO-hoPDUg",
    //     trackTitle: "Glycerine",
    //     songLength: "4:29",
    //     type: "video"
    // },
    // {
    //     iconName: "yiruma",
    //     display_name: "@yiruma",
    //     trackUrl: "",
    //     trackTitle: "River Flows in You",
    //     songLength: "3:09",
    //     type: "audio"
    // },
    // {
    //     iconName: "gunsnroses",
    //     display_name: "@gunsnroses",
    //     trackUrl: "https://www.youtube.com/embed/ASUw44JY-vs",
    //     trackTitle: "November Rain",
    //     songLength: "8:25",
    //     type: "video"
    // }
];

export default data;