export default {
    SUCCESS: `SUCCESS!`,
    DESCRIPTION_ONE: `Your payment was successful.`,
    DESCRIPTION_TWO: `What would you like to do now?`,
    PLACE_NEW_ORDER: `PLACE NEW ORDER`,
    RATE_NEW_TRACKS: `RATE NEW TRACKS`
};