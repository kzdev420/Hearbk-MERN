export default {
    PROCESSING: `PROCESSING`,
    NO_REFESH_TEXT: `Don't refresh the page or press back button`
};