export default {
    SUBCONTAINER4_LABEL: "SUBSCRIPTION",
    SUBCONTAINER4_BOX_LABEL: "Your subscription renews on",
    SUBCONTAINER4_DESCRIPTION: "Your subscription will continue to renew unless you cancel it.",
    SUBCONTAINER4_BUTTON_TEXT: "CANCEL SUBSCRIPTION",
};