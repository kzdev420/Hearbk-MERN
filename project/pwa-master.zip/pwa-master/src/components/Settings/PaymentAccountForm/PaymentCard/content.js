export default {
    WARNING: "Are you sure you want to delete this card?",
    YES: "YES",
    NO: "NO",
    CARD_CONTENT1: "Saved Card",
    CARD_CONTENT2: "/ Ending ",
};