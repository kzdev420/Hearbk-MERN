export default {
    LOGIN_TAB: "LOG IN",
    SIGN_UP_TAB: "SIGN UP",
};