export default {
    TITLE: `PRO FEEDBACK`,
    COL_TITLE_1: `PRO ORDERS`,
    COL_TITLE_2: `AVG RATING`
};