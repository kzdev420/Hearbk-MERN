export default {
    COMMENTS_LABEL: `COMMENTS`
};