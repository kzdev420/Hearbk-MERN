export default {
    MENU_LABEL: "MAIN MENU",
    SEARCH: "Search",
    DISCOVER: "Discover",
    ORDER_FEEDBACK: "Order Feedback",
    ORDER_HISTORY: "Order History",
    SETTINGS: "Settings",
    MORE_LABEL: "MORE",
    MENU_MORE_1: "Listener Preferences",
    MENU_MORE_2: "Give PRO Feedback",
    MENU_MORE_3: "Give Listener Ratings",
    LOGOUT: "LOGOUT"
}