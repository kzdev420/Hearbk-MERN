
export const userSelector = state => state.userDetails;