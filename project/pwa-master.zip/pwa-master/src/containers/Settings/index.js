import SettingsContainer from "./SettingsContainer";

export default SettingsContainer;