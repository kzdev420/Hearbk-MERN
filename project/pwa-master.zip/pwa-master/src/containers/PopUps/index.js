import PopUpsContainer from "./PopUpsContainer";

export default PopUpsContainer;