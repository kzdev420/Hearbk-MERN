import SignUpContainer from './SignUpContainer';

export default SignUpContainer;